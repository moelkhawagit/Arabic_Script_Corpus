import scrapy 
from bs4 import BeautifulSoup
from ..items import WikispiderItem
from scrapy.linkextractors.lxmlhtml import LxmlLinkExtractor

class Wikispider(scrapy.Spider):
    name = "wikispider"
    allowed_domains = ["ar.m.wikipedia.org","ar.wikipedia.org"]
    start_urls = [
        "https://ar.m.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9"
        ]

        # for url in urls:
        #     yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):

      items = WikispiderItem()

      title = response.css("h1::text").extract()
      p = response.css("p").extract()
      soup = BeautifulSoup(str(p), 'lxml')
      l = response.css("html").xpath("@lang").extract_first()
        
      items['title'] = title
      items['text'] = soup.get_text()
      items['lang'] = l
      yield items

      a_selectors = response.xpath("//p/a")
        # Loop on each tag
      for selector in a_selectors:
            #print(selector)
            # Extract the link text
            text = selector.xpath("text()").extract_first()
            # Extract the link href
            link = response.urljoin(selector.xpath("@href").extract_first())
            # Create a new Request object
            yield response.follow(link, callback=self.parse)
            # Return it thanks to a generator
            